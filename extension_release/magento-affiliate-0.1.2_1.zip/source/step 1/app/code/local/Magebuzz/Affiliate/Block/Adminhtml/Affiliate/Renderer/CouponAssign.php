<?php
class Magebuzz_Affiliate_Block_Adminhtml_Affiliate_Renderer_CouponAssign extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
  public function render(Varien_Object $row)
  {
    if ( Mage::getSingleton('adminhtml/session')->getAffiliateData() ) {
      $data = Mage::getSingleton('adminhtml/session')->getAffiliateData();
      Mage::getSingleton('adminhtml/session')->setAffiliateData(null);
    } elseif ( Mage::registry('affiliate_data') ) {
      $data = Mage::registry('affiliate_data')->getData();
    }
    $affiliate_id = $data['affiliate_id'];

    if (!$row->getData('affiliate_id')) return $this->__('Available');
    else {
      if ($affiliate_id == $row->getData('affiliate_id')) return $this->__(' ');
      else {
        return $this->__('Already Assigned to Another');
      }
    }
  }
}
