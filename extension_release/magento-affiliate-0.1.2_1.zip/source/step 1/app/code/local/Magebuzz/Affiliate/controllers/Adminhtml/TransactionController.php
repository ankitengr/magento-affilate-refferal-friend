<?php
/*
* Copyright (c) 2014 www.magebuzz.com
*/
class Magebuzz_Affiliate_Adminhtml_TransactionController extends Mage_Adminhtml_Controller_Action {
  protected function _initAction() {
    $this->loadLayout()
      ->_setActiveMenu('affiliate/transaction')
      ->_addBreadcrumb(Mage::helper('adminhtml')->__('Transaction History'), Mage::helper('adminhtml')->__('Transaction History'));
    return $this;
  }

  public function indexAction() {
    $this->_title($this->__('Affiliate'))
      ->_title($this->__('Transaction  History'));
    $this->_initAction()
      ->renderLayout();
  }
}