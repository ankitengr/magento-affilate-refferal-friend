<?php
/*
* Copyright (c) 2014 www.magebuzz.com
*/

$installer = $this;
$installer->startSetup();

$installer->run("
	ALTER TABLE {$this->getTable('affiliate_affiliate')} ADD `click_number` int DEFAULT '0';
	ALTER TABLE {$this->getTable('affiliate_affiliate')} ADD `unique_click_number` int DEFAULT '0';
	DROP TABLE IF EXISTS {$this->getTable('affiliate_assign_coupon')};
	CREATE TABLE {$this->getTable('affiliate_assign_coupon')} (
		`assign_id` int(11) unsigned NOT NULL auto_increment,
		`affiliate_id` int(11) unsigned NOT NULL,
		`coupon_id` int(11) unsigned NOT NULL,
		`coupon_code` varchar(255) NOT NULL,
		`created_at` datetime NULL,
		FOREIGN KEY (`affiliate_id`) REFERENCES {$this->getTable('affiliate_affiliate')} (`affiliate_id`) ON DELETE CASCADE ON UPDATE CASCADE,
		FOREIGN KEY (`coupon_id`) REFERENCES {$this->getTable('salesrule_coupon')} (`coupon_id`) ON DELETE CASCADE ON UPDATE CASCADE,
		PRIMARY KEY (`assign_id`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;
");

$installer->endSetup(); 