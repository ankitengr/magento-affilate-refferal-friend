<?php
/*
* Copyright (c) 2014 www.magebuzz.com
*/
class Magebuzz_Affiliate_Block_Adminhtml_Transaction_Grid extends Mage_Adminhtml_Block_Widget_Grid {
  public function __construct() {
		parent::__construct();
		$this->setId('transactionGrid');
		$this->setDefaultSort('transaction_id');
		$this->setDefaultDir('DESC');
		$this->setSaveParametersInSession(false);
  }

  protected function _prepareCollection() {
		$collection = Mage::getModel('affiliate/transaction')->getCollection();
    $affiliate_table = Mage::getSingleton('core/resource')->getTableName('affiliate_affiliate');
    $collection->getSelect()->joinLeft(
      array('aa' => $affiliate_table),
      'main_table.affiliate_id = aa.affiliate_id',
      array(
        'affiliate_firstname' => 'aa.firstname',
        'affiliate_lastname' => 'aa.lastname',
      )
    );

    $order_item_table = Mage::getSingleton('core/resource')->getTableName('sales_flat_order_item');
    $collection->getSelect()->joinLeft(
      array('sfoi' => $order_item_table),
      'main_table.item_id = sfoi.item_id',
      array(
        'item_name' => 'sfoi.name',
        'item_sku'  => 'sfoi.sku',
      )
    );

    $this->setCollection($collection);
    return parent::_prepareCollection();
  }

  protected function _prepareColumns() {
    $store = Mage::app()->getStore();

		$this->addColumn('transaction_id', array(
			'header'    => Mage::helper('affiliate')->__('ID'),
			'align'     => 'right',
			'width'     => '50px',
			'index'     => 'transaction_id',
		));

    $this->addColumn('affiliate_firstname', array(
      'header'    => Mage::helper('affiliate')->__('First Name'),
      'align'     => 'right',
      'index'     => 'affiliate_firstname',
    ));

    $this->addColumn('affiliate_lastname', array(
      'header'    => Mage::helper('affiliate')->__('Last Name'),
      'align'     => 'left',
      'index'     => 'affiliate_lastname',
    ));

    $this->addColumn('affiliate_email', array(
      'header'    => Mage::helper('affiliate')->__('Affiliate Email'),
      'align'     => 'left',
      'index'     => 'affiliate_email',
    ));

    $this->addColumn('report',
      array(
        'header'  =>  Mage::helper('affiliate')->__('View order'),
        'type'    => 'action',
        'getter'  => 'getOrderId',
        'actions' => array(
          array(
            'caption' => Mage::helper('affiliate')->__('View Order'),
            'url'   => array('base'=> 'adminhtml/sales_order/view'),
            'field'   => 'order_id'
          )
        ),
        'filter'  => false,
        'sortable'  => false,
        'is_system' => true,
      ));

    $this->addColumn('item_name', array(
      'header'    => Mage::helper('affiliate')->__('Item Name'),
      'align'     => 'left',
      'index'     => 'item_name',
    ));

    $this->addColumn('item_sku', array(
      'header'    => Mage::helper('affiliate')->__('Item SKU'),
      'align'     => 'left',
      'index'     => 'item_sku',
    ));

    $this->addColumn('total_amount', array(
      'header'    => Mage::helper('affiliate')->__('Total Amount'),
      'align'     => 'left',
      'index'     => 'total_amount',
      'type'      => 'number',
      'currency_code' => $store->getBaseCurrency()->getCode(),
    ));

    if (!Mage::app()->isSingleStoreMode()) {
      $this->addColumn('store_id', array(
        'header'    => Mage::helper('affiliate')->__('Purchased From (Store)'),
        'index'     => 'store_id',
        'type'      => 'store',
        'store_view'=> true,
        'display_deleted' => true,
        'filter' => false,
      ));
    }

    $this->addColumn('commission', array(
      'header'    => Mage::helper('affiliate')->__('Commission'),
      'align'     => 'left',
      'index'     => 'commission',
      'type'      => 'price',
      'currency_code' => $store->getBaseCurrency()->getCode(),
    ));

    $this->addColumn('created', array(
      'header'    => Mage::helper('affiliate')->__('Created At'),
      'align'     => 'left',
      'type'      => 'datetime',
      'index'     => 'created',
    ));

		return parent::_prepareColumns();

  }
	
}