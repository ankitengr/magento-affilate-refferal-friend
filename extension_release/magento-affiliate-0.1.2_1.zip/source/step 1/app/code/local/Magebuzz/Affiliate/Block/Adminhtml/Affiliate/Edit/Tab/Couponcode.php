<?php
/*
* Copyright (c) 2014 www.magebuzz.com
*/
class Magebuzz_Affiliate_Block_Adminhtml_Affiliate_Edit_Tab_Couponcode extends Mage_Adminhtml_Block_Widget_Grid {
  public function __construct()
  {
    parent::__construct();
    $this->setId('affiliate_couponcode_grid');
    $this->setDefaultSort('coupon_id','ASC');
    $this->setPagerVisibility(false);
    $this->setFilterVisibility(false);
    $this->setUseAjax(false);
  }

  protected function _getCurrentAffiliateData() {
    if ( Mage::getSingleton('adminhtml/session')->getAffiliateData() ) {
      $data = Mage::getSingleton('adminhtml/session')->getAffiliateData();
      Mage::getSingleton('adminhtml/session')->setAffiliateData(null);
    } elseif ( Mage::registry('affiliate_data') ) {
      $data = Mage::registry('affiliate_data')->getData();
    }
    return $data;
  }

  protected function _getSelectedCouponFromAffiliate()
  {
    $selected_coupon = array();
    $affiliate_data = $this->_getCurrentAffiliateData();
    if (isset($affiliate_data['affiliate_id'])&&($affiliate_data['affiliate_id'])) {
      $collection = Mage::getModel('affiliate/assigncoupon')->getCollection()
        ->addFieldToFilter('affiliate_id',$affiliate_data['affiliate_id']);
      foreach ($collection as $item) {
        $selected_coupon[] = $item->getCouponId();
      }
    }
    return $selected_coupon;
  }

  /**
   * Prepare collection
   *
   * @return Mage_Adminhtml_Block_Widget_Grid
   */
  protected function _prepareCollection()
  {
    $collection = Mage::getModel('salesrule/coupon')
      ->getCollection();

    $collection->getSelect()->joinLeft(
      array('salesrule_table' => Mage::getSingleton('core/resource')->getTableName('salesrule')),
      'main_table.rule_id = salesrule_table.rule_id',
      array('rule_name' => 'salesrule_table.name')
    );

    $collection->getSelect()->joinLeft(
      array('assign_table' => Mage::getSingleton('core/resource')->getTableName('affiliate_assign_coupon')),
      'main_table.coupon_id = assign_table.coupon_id',
      array('affiliate_id' => 'assign_table.affiliate_id')
    );

    $this->setCollection($collection);
    return parent::_prepareCollection();
  }

  /**
   * Add columns to grid
   *
   * @return Mage_Adminhtml_Block_Widget_Grid
   */
  protected function _prepareColumns()
  {
    $this->addColumn('assigned_coupons', array(
      'header_css_class' => 'a-center',
      'type'      => 'checkbox',
      'field_name'=> 'assigned_coupons[]',
      'values'    => $this->_getSelectedCouponFromAffiliate(),
      'align'     => 'center',
      'index'     => 'coupon_id',
    ));

    $this->addColumn('coupon_id', array(
      'header'    => Mage::helper('affiliate')->__('ID'),
      'sortable'  => true,
      'width'     => 60,
      'index'     => 'coupon_id',
    ));

    $this->addColumn('code', array(
      'header'    => Mage::helper('affiliate')->__('Code'),
      'index'     => 'code',
    ));

    $this->addColumn('rule_name', array(
      'header'    => Mage::helper('affiliate')->__('Rule'),
      'type'      => 'text',
      'index'     => 'rule_name',
    ));

    $this->addColumn('affiliate_id', array(
      'header'    => Mage::helper('affiliate')->__('Affiliate ID'),
      'type'      => 'number',
      'index'     => 'affiliate_id',
    ));

    $this->addColumn('affiliate_id', array(
      'header'    => Mage::helper('affiliate')->__('Status'),
      'align'     => 'left',
      'index'     => 'affiliate_id',
      'renderer'  => 'Magebuzz_Affiliate_Block_Adminhtml_Affiliate_Renderer_CouponAssign',
    ));

    return parent::_prepareColumns();
  }
}