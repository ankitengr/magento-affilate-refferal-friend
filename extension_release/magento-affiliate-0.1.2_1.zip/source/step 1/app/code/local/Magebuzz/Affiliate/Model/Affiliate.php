<?php
/*
* Copyright (c) 2014 www.magebuzz.com
*/
class Magebuzz_Affiliate_Model_Affiliate extends Mage_Core_Model_Abstract {
	public function _construct() {
		parent::_construct();
		$this->_init('affiliate/affiliate');
	}
	
	public function loadByCustomerId($customer_id) {
		if (!isset($customer_id) || $customer_id == 0) {
			return false;
		}		
		$adapter = $this->_getReadConnection();
		$query = "Select affiliate_id from ". $this->_getTableName('affiliate_affiliate') ." where customer_id=".$customer_id;

		$result = $adapter->fetchOne($query);
		return $result;
	}

  public function loadByReferralCode($referral_code) {
    return $this->load($referral_code,'referral_code');
  }
	
	protected function _getReadConnection() {
		return Mage::getSingleton('core/resource')->getConnection('core_read');
	}
	
	protected function _getTableName($name) {
		return Mage::getSingleton('core/resource')->getTableName($name);
	}

  protected function getCurrentAssignCoupons() {
    $old_assign_collection = Mage::getModel('affiliate/assigncoupon')->getCollection()->addFieldToFilter('affiliate_id',$this->getId());

    $old_assign_coupons = array();
    foreach ($old_assign_collection as $item) {
      $old_assign_coupons[] = $item->getId();
    }
    return $old_assign_coupons;
  }

  public function assignCoupons($new_assign_coupons) {
    if (is_array($new_assign_coupons)) {
      $old_assign_coupons = $this->getCurrentAssignCoupons();
      $add_new = array_diff($new_assign_coupons,$old_assign_coupons);
      $delete_old = array_diff($old_assign_coupons, $new_assign_coupons);

      /* delete old */
      foreach($delete_old as $coupon_id) {
        $model = Mage::getModel('affiliate/assigncoupon')->load($coupon_id);
        $model->delete();
      }

      /* assign new, override assign if exist */
      foreach ($add_new as $coupon_id) {
        $exist_assign = Mage::getModel('affiliate/assigncoupon')->getCollection()
          ->addFieldToFilter('coupon_id',$coupon_id);
        foreach ($exist_assign as $item) {
          $item->delete();
        }

        $coupon_code = Mage::getModel('salesrule/coupon')->load($coupon_id)->getCode();
        $data = array(
          'affiliate_id'  => $this->getId(),
          'coupon_id'     => $coupon_id,
          'coupon_code'   => (string)$coupon_code,
          'created_at'    => now(),
        );
        Mage::getModel('affiliate/assigncoupon')
          ->setData($data)
          ->save();
      }
    }
  }
}