<?php
/*
* Copyright (c) 2014 www.magebuzz.com
*/
class Magebuzz_Affiliate_Block_Adminhtml_Payment_Statistic extends Mage_Core_Block_Template {

}