<?php
/*
* Copyright (c) 2014 www.magebuzz.com
*/
class Magebuzz_Affiliate_Block_Adminhtml_Transaction extends Mage_Adminhtml_Block_Widget_Grid_Container {
  public function __construct() {
    $this->_controller = 'adminhtml_transaction';
    $this->_blockGroup = 'affiliate';
    $this->_headerText = Mage::helper('affiliate')->__('Transaction History');
    parent::__construct();
    $this->removeButton('add');
  }
}
