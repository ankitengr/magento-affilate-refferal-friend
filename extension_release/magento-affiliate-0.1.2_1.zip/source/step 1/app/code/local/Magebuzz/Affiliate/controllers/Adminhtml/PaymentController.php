<?php
/*
* Copyright (c) 2014 www.magebuzz.com
*/
class Magebuzz_Affiliate_Adminhtml_PaymentController extends Mage_Adminhtml_Controller_Action { 
	public function statisticAction() {
    $this->_title($this->__('Affiliate'))
      ->_title($this->__('Payment Statistic'));
		$this->loadLayout()
			->renderLayout();
	}
}